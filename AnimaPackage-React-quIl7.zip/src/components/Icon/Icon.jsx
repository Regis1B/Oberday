/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Property1AboutUs } from "../../icons/Property1AboutUs";
import { Property1Add } from "../../icons/Property1Add";
import { Property1Arrow } from "../../icons/Property1Arrow";
import { Property1Back } from "../../icons/Property1Back";
import { Property1Bank } from "../../icons/Property1Bank";
import { Property1Bike } from "../../icons/Property1Bike";
import { Property1Book } from "../../icons/Property1Book";
import { Property1Box } from "../../icons/Property1Box";
import { Property1Calender } from "../../icons/Property1Calender";
import { Property1Cancel } from "../../icons/Property1Cancel";
import { Property1Car } from "../../icons/Property1Car";
import { Property1Card } from "../../icons/Property1Card";
import { Property1Chat } from "../../icons/Property1Chat";
import { Property1CheckMark } from "../../icons/Property1CheckMark";
import { Property1Clock } from "../../icons/Property1Clock";
import { Property1Delete } from "../../icons/Property1Delete";
import { Property1Eye } from "../../icons/Property1Eye";
import { Property1EyeOff } from "../../icons/Property1EyeOff";
import { Property1Facebook } from "../../icons/Property1Facebook";
import { Property1Faqs } from "../../icons/Property1Faqs";
import { Property1Fast } from "../../icons/Property1Fast";
import { Property1FastCar } from "../../icons/Property1FastCar";
import { Property1Gift } from "../../icons/Property1Gift";
import { Property1Globe } from "../../icons/Property1Globe";
import { Property1Google } from "../../icons/Property1Google";
import { Property1Help } from "../../icons/Property1Help";
import { Property1History } from "../../icons/Property1History";
import { Property1Home } from "../../icons/Property1Home";
import { Property1Info } from "../../icons/Property1Info";
import { Property1Loader } from "../../icons/Property1Loader";
import { Property1LogOut } from "../../icons/Property1LogOut";
import { Property1Menu } from "../../icons/Property1Menu";
import { Property1Money } from "../../icons/Property1Money";
import { Property1Naira } from "../../icons/Property1Naira";
import { Property1Phone } from "../../icons/Property1Phone";
import { Property1Plane } from "../../icons/Property1Plane";
import { Property1Profile } from "../../icons/Property1Profile";
import { Property1Qm } from "../../icons/Property1Qm";
import { Property1Receive } from "../../icons/Property1Receive";
import { Property1TC } from "../../icons/Property1TC";
import { Property1Truck } from "../../icons/Property1Truck";
import { Property1Wallet } from "../../icons/Property1Wallet";
import "./style.css";

export const Icon = ({ property1 }) => {
  return (
    <>
      {property1 === "profile" && <Property1Profile className="instance-node" />}

      {property1 === "plane" && <Property1Plane className="instance-node" />}

      {property1 === "truck" && <Property1Truck className="instance-node" />}

      {property1 === "card" && <Property1Card className="instance-node" />}

      {property1 === "bike" && <Property1Bike className="instance-node" />}

      {property1 === "wallet" && <Property1Wallet className="instance-node" />}

      {property1 === "home" && <Property1Home className="instance-node" />}

      {property1 === "menu" && <Property1Menu className="instance-node" />}

      {property1 === "car" && <Property1Car className="instance-node" />}

      {property1 === "chat" && <Property1Chat className="instance-node" />}

      {property1 === "log-out" && <Property1LogOut className="instance-node" />}

      {property1 === "help" && <Property1Help className="instance-node" />}

      {property1 === "history" && <Property1History className="instance-node" />}

      {property1 === "faqs" && <Property1Faqs className="instance-node" />}

      {property1 === "t-c" && <Property1TC className="instance-node" />}

      {property1 === "about-us" && <Property1AboutUs className="instance-node" />}

      {property1 === "bell" && (
        <img className="icon property-bell" alt="Property bell" src="/img/property-1-bell.svg" />
      )}

      {property1 === "bell-notification" && (
        <div className="icon overlap-group-wrapper">
          <div className="overlap-group">
            <img className="vector" alt="Vector" src="/img/vector.svg" />
            <div className="ellipse" />
          </div>
        </div>
      )}

      {property1 === "google" && <Property1Google className="instance-node-2" />}

      {property1 === "facebook" && <Property1Facebook className="instance-node-2" />}

      {property1 === "phone" && <Property1Phone className="instance-node" />}

      {property1 === "clock" && <Property1Clock className="instance-node" />}

      {property1 === "check-mark" && <Property1CheckMark className="instance-node" />}

      {property1 === "calender" && <Property1Calender className="instance-node" />}

      {property1 === "bank" && <Property1Bank className="instance-node" />}

      {property1 === "arrow" && <Property1Arrow className="instance-node" />}

      {property1 === "money" && <Property1Money className="instance-node" />}

      {property1 === "gift" && <Property1Gift className="instance-node" />}

      {property1 === "add" && <Property1Add className="instance-node" />}

      {property1 === "delete" && <Property1Delete className="instance-node" />}

      {property1 === "info" && <Property1Info className="instance-node" />}

      {property1 === "eye-off" && <Property1EyeOff className="instance-node" />}

      {property1 === "qm" && <Property1Qm className="instance-node" />}

      {property1 === "book" && <Property1Book className="instance-node" />}

      {property1 === "box" && <Property1Box className="instance-node" />}

      {property1 === "loader" && <Property1Loader className="instance-node" />}

      {property1 === "cancel" && <Property1Cancel className="instance-node" />}

      {property1 === "globe" && <Property1Globe className="instance-node" />}

      {property1 === "back" && <Property1Back className="instance-node" />}

      {property1 === "receive" && <Property1Receive className="instance-node" />}

      {property1 === "fast-car" && <Property1FastCar className="instance-node" />}

      {property1 === "fast" && <Property1Fast className="instance-node" />}

      {property1 === "eye" && <Property1Eye className="instance-node" />}

      {property1 === "naira" && <Property1Naira className="instance-node" />}
    </>
  );
};

Icon.propTypes = {
  property1: PropTypes.oneOf([
    "facebook",
    "info",
    "delete",
    "phone",
    "box",
    "eye-off",
    "eye",
    "faqs",
    "t-c",
    "card",
    "book",
    "fast",
    "loader",
    "back",
    "log-out",
    "bell",
    "cancel",
    "money",
    "bike",
    "naira",
    "chat",
    "bell-notification",
    "plane",
    "bank",
    "fast-car",
    "google",
    "gift",
    "home",
    "menu",
    "history",
    "calender",
    "arrow",
    "clock",
    "qm",
    "add",
    "truck",
    "receive",
    "profile",
    "help",
    "wallet",
    "car",
    "about-us",
    "check-mark",
    "globe",
  ]),
};
