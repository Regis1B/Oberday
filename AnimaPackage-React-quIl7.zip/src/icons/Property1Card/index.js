export { Property1Card } from "./Property1Card";
