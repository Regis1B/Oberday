export { Property1Clock } from "./Property1Clock";
