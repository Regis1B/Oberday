export { Property1Facebook } from "./Property1Facebook";
