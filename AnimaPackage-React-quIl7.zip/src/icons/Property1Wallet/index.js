export { Property1Wallet } from "./Property1Wallet";
