export { Property1Book } from "./Property1Book";
