export { Property1Plane } from "./Property1Plane";
