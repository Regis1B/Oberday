export { Property1Eye } from "./Property1Eye";
