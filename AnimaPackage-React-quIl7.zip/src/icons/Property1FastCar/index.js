export { Property1FastCar } from "./Property1FastCar";
