export { Property1Info } from "./Property1Info";
