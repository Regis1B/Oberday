export { Property1Naira } from "./Property1Naira";
