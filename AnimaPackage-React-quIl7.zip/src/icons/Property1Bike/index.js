export { Property1Bike } from "./Property1Bike";
