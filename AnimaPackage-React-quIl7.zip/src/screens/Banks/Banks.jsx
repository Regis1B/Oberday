import React from "react";
import { Icon } from "../../components/Icon";
import "./style.css";

export const Banks = () => {
  return (
    <div className="banks">
      <div className="frame-wrapper">
        <div className="frame">
          <div className="div-wrapper">
            <div className="text-wrapper">
              <div className="text">CitiBanamex</div>
            </div>
          </div>
          <div className="div-wrapper">
            <div className="text-wrapper">
              <div className="text">BBVA</div>
            </div>
          </div>
          <div className="div">
            <div className="frame-2">
              <div className="frame-3">
                <div className="text-2">Santander</div>
              </div>
            </div>
          </div>
          <div className="frame-4">
            <div className="frame-5">
              <div className="text-3">Banorte</div>
            </div>
          </div>
          <div className="frame-6">
            <div className="frame-7">
              <div className="text-3">Banregio</div>
            </div>
            <Icon property1="eye-off" />
          </div>
        </div>
      </div>
    </div>
  );
};
