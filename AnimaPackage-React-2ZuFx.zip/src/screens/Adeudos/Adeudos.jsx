import React from "react";
import { NavigationBar } from "../../components/NavigationBar";
import { Property1Chevon16 } from "../../icons/Property1Chevon16";
import "./style.css";

export const Adeudos = () => {
  return (
    <div className="adeudos">
      <div className="div-2">
        <div className="frame-2">
          <img className="ic-baseline-arrow" alt="Ic baseline arrow" src="/img/ic-baseline-arrow-back.svg" />
          <img className="vector" alt="Vector" src="/img/vector-8.svg" />
        </div>
        <div className="text-wrapper-2">Adeudo</div>
        <div className="div-wrapper">
          <div className="text-wrapper-3">Agregar metodo de pago</div>
        </div>
        <div className="frame-3">
          <div className="frame-4">
            <div className="text-wrapper-4">Metodos de pago</div>
            <div className="text-wrapper-5">Administrar</div>
          </div>
          <div className="frame-5">
            <div className="frame-6">
              <img className="element" alt="Element" src="/img/6-1.png" />
              <div className="frame-wrapper">
                <div className="frame-7">
                  <div className="text">****9876 (Pato)</div>
                </div>
              </div>
              <div className="frame-8">
                <div className="ellipse" />
                <div className="ellipse" />
                <div className="ellipse" />
              </div>
            </div>
            <div className="frame-9">
              <img className="element-2" alt="Element" src="/img/7-1.png" />
              <div className="frame-wrapper">
                <div className="frame-7">
                  <div className="text">****5712 (Luis)</div>
                </div>
              </div>
              <div className="frame-8">
                <div className="ellipse" />
                <div className="ellipse" />
                <div className="ellipse" />
              </div>
            </div>
            <div className="frame-10">
              <img className="element-3" alt="Element" src="/img/9-1.png" />
              <div className="frame-wrapper">
                <div className="frame-7">
                  <div className="text">Pago en efectivo</div>
                </div>
              </div>
              <div className="frame-8">
                <div className="ellipse" />
                <div className="ellipse" />
                <div className="ellipse" />
              </div>
            </div>
          </div>
        </div>
        <div className="frame-11">
          <div className="frame-7">
            <div className="text-wrapper-6">Agosto 2022</div>
            <div className="text-wrapper-7">$47,297</div>
          </div>
          <div className="frame-12">
            <div className="frame-13">
              <div className="text-wrapper-8">Mes</div>
              <Property1Chevon16 className="icon" />
            </div>
          </div>
        </div>
        <div className="overlap">
          <div className="status-bar">
            <div className="wrapper">
              <img className="time" alt="Time" src="/img/time.svg" />
              <div className="right-side">
                <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
                <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
                <img className="battery" alt="Battery" src="/img/battery.png" />
              </div>
            </div>
          </div>
          <img className="element-4" alt="Element" src="/img/10-1.png" />
        </div>
        <NavigationBar
          className="navigation-bar-instance"
          divClassName="frame-14"
          divClassNameOverride="frame-15"
          hasFrame={false}
          majesticons="/img/majesticons-calculator-1.svg"
          overlapGroupClassName="design-component-instance-node"
          riHomeFill="/img/ri-home-6-fill-1.svg"
          text="Trayecto"
          text1="Formación"
          text2="Movimientos"
          text3="Perfil"
          vector="/img/vector-7.svg"
        />
      </div>
    </div>
  );
};
