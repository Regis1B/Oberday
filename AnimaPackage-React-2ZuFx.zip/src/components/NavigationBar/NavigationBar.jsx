/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const NavigationBar = ({
  className,
  overlapGroupClassName,
  riHomeFill = "/img/ri-home-6-fill.svg",
  divClassName,
  text = "Home",
  hasFrame = true,
  majesticons = "/img/majesticons-calculator.svg",
  divClassNameOverride,
  text1 = "Budget",
  vector = "/img/vector.svg",
  text2 = "Stats",
  text3 = "Profile",
}) => {
  return (
    <div className={`navigation-bar ${className}`}>
      <div className={`overlap-group ${overlapGroupClassName}`}>
        <div className="frame">
          <div className="div">
            <img className="img" alt="Ri home fill" src={riHomeFill} />
            <div className={`home ${divClassName}`}>{text}</div>
          </div>
          {hasFrame && (
            <div className="div">
              <img className="img" alt="Material symbols" src="/img/material-symbols-credit-card-outline.svg" />
              <div className="text-wrapper">Card</div>
            </div>
          )}

          <div className="div">
            <img className="img" alt="Majesticons" src={majesticons} />
            <div className={`text-wrapper ${divClassNameOverride}`}>{text1}</div>
          </div>
          <div className="div">
            <img className="img" alt="Vector" src={vector} />
            <div className="text-wrapper">{text2}</div>
          </div>
          <div className="div">
            <img className="img" alt="Ri user fill" src="/img/ri-user-6-fill.svg" />
            <div className="text-wrapper">{text3}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

NavigationBar.propTypes = {
  riHomeFill: PropTypes.string,
  text: PropTypes.string,
  hasFrame: PropTypes.bool,
  majesticons: PropTypes.string,
  text1: PropTypes.string,
  vector: PropTypes.string,
  text2: PropTypes.string,
  text3: PropTypes.string,
};
