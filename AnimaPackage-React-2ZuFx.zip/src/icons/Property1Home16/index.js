export { Property1Home16 } from "./Property1Home16";
