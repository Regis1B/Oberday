/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1Plus16 = ({ className }) => {
  return (
    <svg
      className={`property-1-plus-16 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M8.77419 0.774194C8.77419 0.346622 8.42756 0 8 0C7.57243 0 7.22581 0.346622 7.22581 0.774194V7.22581H0.774194C0.346622 7.22581 0 7.57243 0 8C0 8.42756 0.346622 8.77419 0.774194 8.77419H7.22581V15.2258C7.22581 15.6534 7.57243 16 8 16C8.42756 16 8.77419 15.6534 8.77419 15.2258V8.77419H15.2258C15.6534 8.77419 16 8.42756 16 8C16 7.57243 15.6534 7.22581 15.2258 7.22581H8.77419V0.774194Z"
        fill="white"
      />
    </svg>
  );
};
