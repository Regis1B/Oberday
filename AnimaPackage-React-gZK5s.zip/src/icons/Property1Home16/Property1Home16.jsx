/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1Home16 = ({ className }) => {
  return (
    <svg
      className={`property-1-home-16 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M7.50885 0.168514C7.79773 -0.0561712 8.20227 -0.0561712 8.49115 0.168514L15.0734 5.2881C15.6581 5.74278 16 6.44192 16 7.18253V14.4C16 15.2837 15.2837 16 14.4 16H11.2C10.3164 16 9.6 15.2837 9.6 14.4V9.6H6.4V14.4C6.4 15.2837 5.68365 16 4.8 16H1.6C0.716352 16 0 15.2837 0 14.4V7.18253C0 6.44192 0.341936 5.74278 0.926544 5.2881L7.50885 0.168514ZM8 1.81349L1.90885 6.55106C1.71398 6.70262 1.6 6.93567 1.6 7.18253V14.4H4.8V9.6C4.8 8.71635 5.51635 8 6.4 8H9.6C10.4836 8 11.2 8.71635 11.2 9.6V14.4H14.4V7.18253C14.4 6.93567 14.286 6.70262 14.0912 6.55106L8 1.81349Z"
        fill="white"
      />
    </svg>
  );
};
