export { Property1Home24 } from "./Property1Home24";
