/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const NavigationBar = ({
  className,
  riHomeFill = "/img/ri-home-6-fill.svg",
  divClassName,
  text = "Home",
  hasFrame = true,
  text1 = "Budget",
  vector = "/img/vector-8.svg",
  divClassNameOverride,
  text2 = "Stats",
  text3 = "Profile",
}) => {
  return (
    <div className={`navigation-bar ${className}`}>
      <div className="overlap-group">
        <div className="frame">
          <div className="div">
            <img className="img" alt="Ri home fill" src={riHomeFill} />
            <div className={`home ${divClassName}`}>{text}</div>
          </div>
          {hasFrame && (
            <div className="div">
              <img className="img" alt="Material symbols" src="/img/material-symbols-credit-card-outline.svg" />
              <div className="text-wrapper">Card</div>
            </div>
          )}

          <div className="div">
            <img className="img" alt="Majesticons" src="/img/majesticons-calculator-1.svg" />
            <div className="text-wrapper">{text1}</div>
          </div>
          <div className="div">
            <img className="img" alt="Vector" src={vector} />
            <div className={`text-wrapper ${divClassNameOverride}`}>{text2}</div>
          </div>
          <div className="div">
            <img className="img" alt="Ri user fill" src="/img/ri-user-6-fill-1.svg" />
            <div className="text-wrapper">{text3}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

NavigationBar.propTypes = {
  riHomeFill: PropTypes.string,
  text: PropTypes.string,
  hasFrame: PropTypes.bool,
  text1: PropTypes.string,
  vector: PropTypes.string,
  text2: PropTypes.string,
  text3: PropTypes.string,
};
