import React from "react";
import { NavigationBar } from "../../components/NavigationBar";
import { Property1Chevon16 } from "../../icons/Property1Chevon16";
import "./style.css";

export const Shopping = () => {
  return (
    <div className="shopping">
      <div className="div-2">
        <div className="text-wrapper-2">Mis compras</div>
        <div className="frame-2">
          <div className="frame-3">
            <div className="text-wrapper-3">Transacciones de Agosto</div>
            <div className="text-wrapper-4">Ver todo</div>
          </div>
          <div className="frame-4">
            <div className="frame-5">
              <div className="frame-6">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Ph book fill" src="/img/ph-book-fill.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="ellipse-wrapper">
                        <img className="ellipse" alt="Ellipse" src="/img/ellipse-44-4.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="group-2">
                  <div className="text">Libros</div>
                  <p className="p">Agosto 14 - 02:35 pm</p>
                </div>
              </div>
              <div className="text-2">$45.98</div>
            </div>
            <div className="frame-5">
              <div className="frame-6">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Ic baseline local" src="/img/ic-baseline-local-movies.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="img-wrapper">
                        <img className="ellipse" alt="Ellipse" src="/img/ellipse-44-3.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="group-3">
                  <div className="text-3">Pelicula</div>
                  <p className="text-4">Agosto 14 - 02:35 pm</p>
                </div>
              </div>
              <div className="text-5">$45.98</div>
            </div>
            <div className="frame-5">
              <div className="frame-6">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Ic round directions" src="/img/ic-round-directions-car-filled.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <img className="ellipse" alt="Ellipse" src="/img/ellipse-44-2.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="group-3">
                  <div className="text-3">Aceite de auto</div>
                  <p className="text-4">Agosto 14 - 02:35 pm</p>
                </div>
              </div>
              <div className="text-5">$45.98</div>
            </div>
            <div className="frame-5">
              <div className="frame-6">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Icon park solid fork" src="/img/icon-park-solid-fork-spoon.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-3">
                        <img className="ellipse" alt="Ellipse" src="/img/ellipse-44-1.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="group-3">
                  <div className="text-3">Cena</div>
                  <p className="text-4">Agosto 14 - 02:35 pm</p>
                </div>
              </div>
              <div className="text-5">$45.98</div>
            </div>
            <div className="frame-5">
              <div className="frame-6">
                <div className="group">
                  <div className="overlap">
                    <img
                      className="material-symbols"
                      alt="Material symbols"
                      src="/img/material-symbols-arrow-right-alt-rounded-2.svg"
                    />
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-4">
                        <img className="ellipse" alt="Ellipse" src="/img/ellipse-44.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="overlap-wrapper">
                  <div className="overlap-2">
                    <div className="text-6">Transaccion de Jane</div>
                    <p className="text-4">Agosto 14 - 02:35 pm</p>
                  </div>
                </div>
              </div>
              <div className="text-7">$45.98</div>
            </div>
          </div>
        </div>
        <div className="overlap-3">
          <div className="status-bar">
            <div className="wrapper">
              <img className="time" alt="Time" src="/img/time.svg" />
              <div className="right-side">
                <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
                <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
                <img className="battery" alt="Battery" src="/img/battery.png" />
              </div>
            </div>
          </div>
          <div className="frame-7">
            <img className="ic-baseline-arrow" alt="Ic baseline arrow" src="/img/ic-baseline-arrow-back.svg" />
            <img className="vector" alt="Vector" src="/img/vector-1.svg" />
          </div>
          <img className="element" alt="Element" src="/img/10-1.png" />
        </div>
        <div className="text-wrapper-5">Aguas con las estadísticas</div>
        <div className="text-wrapper-6">Mis gastos e ingresos</div>
        <div className="div-wrapper">
          <div className="overlap-4">
            <div className="group-wrapper">
              <div className="group-4">
                <div className="overlap-group-5">
                  <img className="line" alt="Line" src="/img/line-2.svg" />
                  <div className="frame-8">
                    <div className="frame-9">
                      <div className="frame-10">
                        <div className="rectangle" />
                        <div className="rectangle-2" />
                      </div>
                      <div className="text-wrapper-7">Ene</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-3" />
                        <div className="rectangle-4" />
                      </div>
                      <div className="text-wrapper-7">Feb</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-5" />
                        <div className="rectangle-6" />
                      </div>
                      <div className="text-wrapper-7">Mar</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-7" />
                        <div className="rectangle-8" />
                      </div>
                      <div className="text-wrapper-7">Abr</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-3" />
                        <div className="rectangle-9" />
                      </div>
                      <div className="text-wrapper-7">May</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-10" />
                        <div className="rectangle-11" />
                      </div>
                      <div className="text-wrapper-7">Jun</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-12" />
                        <div className="rectangle-13" />
                      </div>
                      <div className="text-wrapper-7">Jul</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-14" />
                        <div className="rectangle-15" />
                      </div>
                      <div className="text-wrapper-7">Aug</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-16" />
                        <div className="rectangle-2" />
                      </div>
                      <div className="text-wrapper-7">Sept</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-3" />
                        <div className="rectangle-9" />
                      </div>
                      <div className="text-wrapper-7">Oct</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-17" />
                        <div className="rectangle-18" />
                      </div>
                      <div className="text-wrapper-7">Nov</div>
                    </div>
                    <div className="frame-9">
                      <div className="frame-11">
                        <div className="rectangle-19" />
                        <div className="rectangle-13" />
                      </div>
                      <div className="text-wrapper-7">Dec</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="frame-12">
              <div className="text-wrapper-8">$2000</div>
              <div className="text-wrapper-7">$1500</div>
              <div className="text-wrapper-7">$1200</div>
              <div className="text-wrapper-7">$1000</div>
              <div className="text-wrapper-7">$500</div>
              <div className="text-wrapper-7">$200</div>
              <div className="text-wrapper-7">0</div>
            </div>
          </div>
        </div>
        <div className="frame-13">
          <div className="frame-14">
            <div className="frame-15">
              <div className="rectangle-20" />
              <div className="text-wrapper-9">Ingresos</div>
            </div>
            <div className="frame-15">
              <div className="rectangle-21" />
              <div className="text-wrapper-9">Gastos</div>
            </div>
          </div>
          <div className="frame-wrapper">
            <div className="frame-16">
              <div className="text-wrapper-10">Año</div>
              <Property1Chevon16 className="icon" />
            </div>
          </div>
        </div>
        <div className="frame-17">
          <div className="text-wrapper-11">Estadísticas mensuales</div>
          <div className="element-2">
            <div className="frame-18">
              <div className="frame-19">
                <div className="frame-20">
                  <div className="text-wrapper-12">Ahorros de Octubre</div>
                  <div className="frame-21">
                    <div className="ellipse-2" />
                    <div className="ellipse-3" />
                    <div className="ellipse-4" />
                  </div>
                </div>
                <div className="text-wrapper-13">$18,836.00</div>
              </div>
              <div className="frame-22">
                <div className="material-symbols-wrapper">
                  <img
                    className="material-symbols-2"
                    alt="Material symbols"
                    src="/img/material-symbols-arrow-right-alt-rounded.svg"
                  />
                </div>
                <div className="text-wrapper-14">+12%</div>
                <div className="text-wrapper-15">Mas que Septiembre</div>
              </div>
            </div>
            <div className="frame-18">
              <div className="frame-19">
                <div className="frame-23">
                  <div className="text-wrapper-16">Ahorros de Septiembre</div>
                  <div className="frame-24">
                    <div className="ellipse-2" />
                    <div className="ellipse-3" />
                    <div className="ellipse-4" />
                  </div>
                </div>
                <div className="text-wrapper-13">$18,836.00</div>
              </div>
              <div className="frame-22">
                <div className="material-symbols-wrapper">
                  <img
                    className="material-symbols-2"
                    alt="Material symbols"
                    src="/img/material-symbols-arrow-right-alt-rounded.svg"
                  />
                </div>
                <div className="text-wrapper-14">+12%</div>
                <div className="text-wrapper-15">Mas que Agosto</div>
              </div>
            </div>
          </div>
        </div>
        <img className="image" alt="Image" src="/img/image-2.png" />
        <NavigationBar
          className="navigation-bar-instance"
          divClassName="design-component-instance-node"
          divClassNameOverride="frame-25"
          hasFrame={false}
          riHomeFill="/img/ri-home-6-fill-1.svg"
          text="Trayecto"
          text1="Formación"
          text2="Movimientos"
          text3="Perfil"
          vector="/img/vector.svg"
        />
      </div>
    </div>
  );
};
