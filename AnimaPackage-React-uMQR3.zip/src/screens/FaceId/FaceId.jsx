import React from "react";
import "./style.css";

export const FaceId = () => {
  return (
    <div className="face-id">
      <div className="div">
        <div className="text-wrapper">Reconocimiento de identificación facial</div>
        <p className="p">Lorem ipsum dolor sit amet consectetur. Nullam sodales purus nulla in sapien quam.</p>
        <div className="frame">
          <div className="text-wrapper-2">Empezar</div>
        </div>
        <img className="teenyicons-face-id" alt="Teenyicons face id" src="/img/teenyicons-face-id-solid.svg" />
        <p className="no-estas-listo-para">
          <span className="span">¿No estas listo para el escaner? </span>
          <span className="text-wrapper-3">Saltar</span>
        </p>
        <div className="status-bar">
          <div className="wrapper">
            <img className="time" alt="Time" src="/img/time.svg" />
            <div className="right-side">
              <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
              <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
              <img className="battery" alt="Battery" src="/img/battery.png" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
