import { NavigationBar } from ".";

export default {
  title: "Components/NavigationBar",
  component: NavigationBar,
};

export const Default = {
  args: {
    className: {},
    riHomeFill: "/img/ri-home-6-fill.svg",
    divClassName: {},
    text: "Home",
    hasFrame: true,
    text1: "Budget",
    text2: "Stats",
    riUserFill: "/img/ri-user-6-fill.svg",
    divClassNameOverride: {},
    text3: "Profile",
    vector: "/img/vector.svg",
  },
};
