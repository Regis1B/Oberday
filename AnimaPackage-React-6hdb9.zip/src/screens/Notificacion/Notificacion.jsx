import React from "react";
import { NavigationBar } from "../../components/NavigationBar";
import { Icon } from "../../icons/Icon";
import "./style.css";

export const Notificacion = () => {
  return (
    <div className="notificacion">
      <div className="div-2">
        <div className="overlap">
          <div className="ic-baseline-arrow-wrapper">
            <img className="ic-baseline-arrow" alt="Ic baseline arrow" src="/img/ic-baseline-arrow-back.svg" />
          </div>
        </div>
        <div className="text-wrapper-2">Notificaciones</div>
        <div className="frame-2">
          <div className="text-wrapper-3">Configuraciones de seguridad</div>
          <div className="frame-3">
            <div className="frame-wrapper">
              <div className="frame-4">
                <div className="group">
                  <img className="img-2" alt="Material symbols" src="/img/material-symbols-security-rounded-1.svg" />
                </div>
                <p className="text">El consejo del día de hoy es</p>
              </div>
            </div>
            <div className="frame-wrapper">
              <div className="frame-4">
                <div className="group">
                  <img className="img-2" alt="Material symbols" src="/img/material-symbols-security-rounded.svg" />
                </div>
                <p className="text">El consejo del día de hoy es</p>
              </div>
            </div>
            <div className="div-wrapper">
              <div className="frame-4">
                <div className="group-2">
                  <img className="img-2" alt="Grommet icons finger" src="/img/grommet-icons-finger-print.svg" />
                </div>
                <p className="p">Alerta, se ha detectado acti</p>
              </div>
            </div>
            <div className="frame-wrapper">
              <div className="frame-4">
                <div className="group">
                  <img className="img-2" alt="Material symbols" src="/img/material-symbols-credit-card-outline-2.svg" />
                </div>
                <div className="text">Los productos recomendad</div>
              </div>
            </div>
            <div className="frame-wrapper">
              <div className="frame-4">
                <div className="group">
                  <img className="img-2" alt="Material symbols" src="/img/material-symbols-credit-card-outline-1.svg" />
                </div>
                <p className="text">Es momento de invertir el bi</p>
              </div>
            </div>
          </div>
        </div>
        <div className="overlap-2">
          <div className="frame-5">
            <div className="text-wrapper-3">General</div>
            <div className="frame-6">
              <div className="frame-7">
                <div className="frame-8">
                  <div className="group-2">
                    <Icon className="icon-instance" />
                  </div>
                  <div className="text-2">Notificaciones</div>
                </div>
              </div>
              <div className="frame-7">
                <div className="frame-8">
                  <div className="group-2">
                    <img className="img-2" alt="Mdi about variant" src="/img/mdi-about-variant.svg" />
                  </div>
                  <div className="text-2">Acerca de nosotros</div>
                </div>
              </div>
            </div>
          </div>
          <div className="frame-5">
            <div className="text-wrapper-3">General</div>
            <div className="frame-6">
              <div className="frame-7">
                <div className="frame-8">
                  <div className="group-2">
                    <img className="img-2" alt="Mdi about variant" src="/img/mdi-about-variant.svg" />
                  </div>
                  <div className="text-2">Acerca de nosotros</div>
                </div>
              </div>
              <div className="frame-7">
                <div className="frame-8">
                  <div className="group-2">
                    <img className="img-2" alt="Iconoir headset help" src="/img/iconoir-headset-help.svg" />
                  </div>
                  <div className="text-2">Asistencia al cliente</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="overlap-3">
          <div className="status-bar">
            <div className="wrapper">
              <img className="time" alt="Time" src="/img/time.svg" />
              <div className="right-side">
                <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
                <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
                <img className="battery" alt="Battery" src="/img/battery.png" />
              </div>
            </div>
          </div>
          <div className="status-bar">
            <div className="wrapper">
              <img className="time" alt="Time" src="/img/time.svg" />
              <div className="right-side">
                <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
                <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
                <img className="battery" alt="Battery" src="/img/battery.png" />
              </div>
            </div>
          </div>
        </div>
        <NavigationBar
          className="navigation-bar-instance"
          divClassName="design-component-instance-node"
          divClassNameOverride="frame-9"
          hasFrame={false}
          riHomeFill="/img/ri-home-6-fill-1.svg"
          riUserFill="/img/ri-user-6-fill-1.svg"
          text="Trayecto"
          text1="Formación"
          text2="Acciones"
          text3="Perfil"
        />
        <div className="overlap-4">
          <div className="text-wrapper-4">4</div>
        </div>
        <NavigationBar
          className="frame-10"
          divClassName="design-component-instance-node"
          divClassNameOverride="frame-9"
          hasFrame={false}
          riHomeFill="/img/ri-home-6-fill-1.svg"
          riUserFill="/img/ri-user-6-fill-1.svg"
          text="Trayecto"
          text1="Formación"
          text2="Movimientos"
          text3="Perfil"
          vector="/img/vector-7.svg"
        />
      </div>
    </div>
  );
};
