export { Property1Chart24 } from "./Property1Chart24";
