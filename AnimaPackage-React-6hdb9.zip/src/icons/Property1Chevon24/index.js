export { Property1Chevon24 } from "./Property1Chevon24";
