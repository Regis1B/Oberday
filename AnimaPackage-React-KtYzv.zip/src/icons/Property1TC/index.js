export { Property1TC } from "./Property1TC";
