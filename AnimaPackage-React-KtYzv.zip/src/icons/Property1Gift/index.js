export { Property1Gift } from "./Property1Gift";
