/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1Box = ({ className }) => {
  return (
    <svg
      className={`property-1-box ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_219_822)">
        <path
          className="path"
          clipRule="evenodd"
          d="M23.292 4.45955C23.5008 4.54289 23.6799 4.68689 23.8061 4.87298C23.9323 5.05907 23.9998 5.2787 24 5.50355V18.4965C23.9998 18.7214 23.9323 18.941 23.8061 19.1271C23.6799 19.3132 23.5008 19.4572 23.292 19.5405L12.417 23.8905C12.1488 23.9978 11.8497 23.9978 11.5815 23.8905L0.7065 19.5405C0.497953 19.457 0.319208 19.3129 0.193291 19.1268C0.0673734 18.9407 5.22899e-05 18.7212 0 18.4965L0 5.50355C5.22899e-05 5.27888 0.0673734 5.05937 0.193291 4.8733C0.319208 4.68723 0.497953 4.54312 0.7065 4.45955L11.1645 0.276047L11.1795 0.271547L11.5815 0.109547C11.8501 0.00189587 12.1499 0.00189587 12.4185 0.109547L12.822 0.271547L12.837 0.276047L23.292 4.45955ZM15.606 3.00005L6.375 6.69155L2.769 5.25005L1.5 5.75855V6.35855L11.25 10.2585V22.1415L12 22.4415L12.75 22.1415V10.26L22.5 6.36005V5.76005L21.231 5.25155L12 8.94155L8.394 7.50005L17.625 3.80855L15.606 3.00005Z"
          fill="white"
          fillRule="evenodd"
        />
      </g>
      <defs className="defs">
        <clipPath className="clip-path" id="clip0_219_822">
          <rect className="rect" fill="white" height="24" width="24" />
        </clipPath>
      </defs>
    </svg>
  );
};
