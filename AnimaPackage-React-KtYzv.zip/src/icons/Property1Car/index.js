export { Property1Car } from "./Property1Car";
