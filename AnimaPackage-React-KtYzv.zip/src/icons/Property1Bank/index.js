export { Property1Bank } from "./Property1Bank";
