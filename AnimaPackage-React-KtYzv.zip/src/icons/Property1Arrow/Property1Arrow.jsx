/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1Arrow = ({ className }) => {
  return (
    <svg
      className={`property-1-arrow ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M9 13.5899L17.607 4.98291L19.021 6.39691L10.414 15.0039H18V17.0039H7V6.00391H9V13.5889V13.5899Z"
        fill="white"
      />
    </svg>
  );
};
