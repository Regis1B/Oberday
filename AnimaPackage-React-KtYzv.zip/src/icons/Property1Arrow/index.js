export { Property1Arrow } from "./Property1Arrow";
