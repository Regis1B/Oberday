export { Property1Money } from "./Property1Money";
