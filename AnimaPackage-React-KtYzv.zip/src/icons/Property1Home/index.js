export { Property1Home } from "./Property1Home";
