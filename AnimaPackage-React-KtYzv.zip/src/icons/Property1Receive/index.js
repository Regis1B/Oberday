export { Property1Receive } from "./Property1Receive";
