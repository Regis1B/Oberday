import React from "react";
import { Property1EyeOff } from "../../icons/Property1EyeOff";
import { Property1Google } from "../../icons/Property1Google";
import "./style.css";

export const CreateAccount = () => {
  return (
    <div className="create-account">
      <div className="div">
        <div className="text-wrapper">Crear una cuenta</div>
        <p className="p">
          Obtén una cuenta y administra mejor tus finanzas con control total de tus presupuestos y ahorros.
        </p>
        <div className="group">
          <div className="overlap-group">
            <img className="line" alt="Line" src="/img/line-15.svg" />
            <div className="frame">
              <p className="text-wrapper-2">O crea una cuenta con</p>
            </div>
          </div>
        </div>
        <p className="al-crear-una-cuenta"> Al crear una cuenta, aceptas los TÉRMINOS Y CONDICIONES de Track Buddy.</p>
        <div className="frame-wrapper">
          <div className="frame-2">
            <Property1Google className="icon" />
            <div className="text">Google</div>
          </div>
        </div>
        <p className="ya-tienes-una-cuenta">
          <span className="span">¿Ya tienes una cuenta? </span>
          <span className="text-wrapper-3">Inicia sesión</span>
        </p>
        <div className="div-wrapper">
          <div className="text-wrapper-4">Crear cuenta</div>
        </div>
        <div className="frame-3">
          <div className="frame-4">
            <div className="frame-5">
              <div className="text-2">Nombre</div>
              <div className="text-3">Ingresa tu nombre</div>
            </div>
          </div>
          <div className="frame-6">
            <div className="frame-5">
              <div className="text-2">Correo *</div>
              <div className="text-3">Ingresa tu correo</div>
            </div>
          </div>
          <div className="frame-7">
            <img className="img" alt="Frame" src="/img/frame-239001.svg" />
            <div className="frame-8">
              <div className="frame-9">
                <div className="text-4">Numero de teléfono</div>
                <div className="text-5">Ingresar número</div>
              </div>
            </div>
          </div>
          <div className="frame-10">
            <div className="frame-11">
              <div className="text-4">Contraseña</div>
              <div className="text-6">Ingresar contraseña</div>
            </div>
            <Property1EyeOff className="property-1-eye-off" color="#1A2D40" opacity="0.2" />
          </div>
          <div className="frame-10">
            <div className="frame-11">
              <div className="text-4">Confrimar contraseña</div>
              <div className="text-6">Ingresar contraseña</div>
            </div>
            <Property1EyeOff className="property-1-eye-off" color="#1A2D40" opacity="0.2" />
          </div>
        </div>
        <div className="status-bar">
          <div className="wrapper">
            <img className="time" alt="Time" src="/img/time.svg" />
            <div className="right-side">
              <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
              <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
              <img className="battery" alt="Battery" src="/img/battery.png" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
