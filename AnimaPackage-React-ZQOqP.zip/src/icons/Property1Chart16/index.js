export { Property1Chart16 } from "./Property1Chart16";
