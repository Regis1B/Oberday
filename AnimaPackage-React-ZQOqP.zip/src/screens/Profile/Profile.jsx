import React from "react";
import { NavigationBar } from "../../components/NavigationBar";
import { Icon } from "../../icons/Icon";
import "./style.css";

export const Profile = () => {
  return (
    <div className="profile">
      <div className="div-2">
        <div className="overlap">
          <div className="frame-2">
            <img className="ic-baseline-arrow" alt="Ic baseline arrow" src="/img/ic-baseline-arrow-back.svg" />
            <img className="vector" alt="Vector" src="/img/vector-9.svg" />
          </div>
        </div>
        <div className="overlap-2">
          <div className="text-wrapper-2">Perfil</div>
          <div className="text-wrapper-2">Perfil</div>
        </div>
        <div className="overlap-3">
          <div className="frame-3">
            <div className="text-wrapper-3">Configuración de la cuenta</div>
            <div className="frame-wrapper">
              <div className="frame-4">
                <div className="group">
                  <img className="img-2" alt="Ri user fill" src="/img/ri-user-6-fill-3.svg" />
                </div>
                <div className="text">Información de la cuenta</div>
              </div>
            </div>
          </div>
          <div className="frame-3">
            <div className="text-wrapper-3">Configuración de la cuenta</div>
            <div className="frame-wrapper">
              <div className="frame-4">
                <div className="group">
                  <img className="img-2" alt="Ri user fill" src="/img/ri-user-6-fill-3.svg" />
                </div>
                <div className="text">Información de la cuenta</div>
              </div>
            </div>
          </div>
        </div>
        <div className="overlap-4">
          <div className="frame-3">
            <div className="text-wrapper-3">Configuraciones de seguridad</div>
            <div className="frame-5">
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Material symbols" src="/img/material-symbols-security-rounded.svg" />
                  </div>
                  <div className="text">Contraseña</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Grommet icons finger" src="/img/grommet-icons-finger-print.svg" />
                  </div>
                  <div className="text-2">Huella y reconocimiento facial</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img
                      className="img-2"
                      alt="Material symbols"
                      src="/img/material-symbols-credit-card-outline-1.svg"
                    />
                  </div>
                  <div className="text">Cuentas y tarjetas</div>
                </div>
              </div>
            </div>
          </div>
          <div className="frame-3">
            <div className="text-wrapper-3">Configuraciones de seguridad</div>
            <div className="frame-5">
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Material symbols" src="/img/material-symbols-security-rounded.svg" />
                  </div>
                  <div className="text">Contraseña</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Grommet icons finger" src="/img/grommet-icons-finger-print.svg" />
                  </div>
                  <div className="text-2">Huella y reconocimiento facial</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img
                      className="img-2"
                      alt="Material symbols"
                      src="/img/material-symbols-credit-card-outline-1.svg"
                    />
                  </div>
                  <div className="text">Cuentas y tarjetas</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="overlap-5">
          <div className="frame-3">
            <div className="text-wrapper-3">General</div>
            <div className="frame-5">
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <Icon className="icon-instance" />
                  </div>
                  <div className="text">Notificaciones</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Mdi about variant" src="/img/mdi-about-variant.svg" />
                  </div>
                  <div className="text">Acerca de nosotros</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Iconoir headset help" src="/img/iconoir-headset-help.svg" />
                  </div>
                  <div className="text">Cliente</div>
                </div>
              </div>
            </div>
          </div>
          <div className="frame-3">
            <div className="text-wrapper-3">General</div>
            <div className="frame-5">
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <Icon className="icon-instance" />
                  </div>
                  <div className="text">Notificaciones</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Mdi about variant" src="/img/mdi-about-variant.svg" />
                  </div>
                  <div className="text">Acerca de nosotros</div>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="frame-4">
                  <div className="group">
                    <img className="img-2" alt="Iconoir headset help" src="/img/iconoir-headset-help.svg" />
                  </div>
                  <div className="text">Asistencia al cliente</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="overlap-6">
          <div className="status-bar">
            <div className="wrapper">
              <img className="time" alt="Time" src="/img/time.svg" />
              <div className="right-side">
                <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
                <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
                <img className="battery" alt="Battery" src="/img/battery.png" />
              </div>
            </div>
          </div>
          <div className="status-bar">
            <div className="wrapper">
              <img className="time" alt="Time" src="/img/time.svg" />
              <div className="right-side">
                <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
                <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
                <img className="battery" alt="Battery" src="/img/battery.png" />
              </div>
            </div>
          </div>
          <img className="element" alt="Element" src="/img/10-1.png" />
        </div>
        <NavigationBar
          className="navigation-bar-instance"
          divClassName="design-component-instance-node"
          divClassNameOverride="frame-6"
          hasFrame={false}
          riHomeFill="/img/ri-home-6-fill-1.svg"
          riUserFill="/img/ri-user-6-fill-1.svg"
          text="Trayecto"
          text1="Formación"
          text2="Acciones"
          text3="Perfil"
        />
        <NavigationBar
          className="frame-7"
          divClassName="design-component-instance-node"
          divClassNameOverride="frame-6"
          hasFrame={false}
          riHomeFill="/img/ri-home-6-fill-1.svg"
          riUserFill="/img/ri-user-6-fill-1.svg"
          text="Trayecto"
          text1="Formación"
          text2="Movimientos"
          text3="Perfil"
          vector="/img/vector-7.svg"
        />
      </div>
    </div>
  );
};
