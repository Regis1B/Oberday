import React from "react";
import "./style.css";

export const Page = () => {
  return (
    <div className="page">
      <div className="div">
        <p className="text-wrapper">Te ayudamos a mejorar tu score de crédito</p>
        <img className="element" alt="Element" src="/img/2-775.png" />
      </div>
    </div>
  );
};
