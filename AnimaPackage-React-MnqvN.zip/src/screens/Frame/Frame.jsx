import React from "react";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="frame-wrapper">
        <div className="div" />
      </div>
    </div>
  );
};
