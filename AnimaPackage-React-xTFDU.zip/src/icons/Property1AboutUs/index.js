export { Property1AboutUs } from "./Property1AboutUs";
