export { Property1Truck } from "./Property1Truck";
