export { Property1Faqs } from "./Property1Faqs";
