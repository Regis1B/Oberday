export { Property1Google } from "./Property1Google";
