export { Property1Globe } from "./Property1Globe";
