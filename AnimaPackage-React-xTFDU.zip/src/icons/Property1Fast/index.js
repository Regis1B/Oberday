export { Property1Fast } from "./Property1Fast";
