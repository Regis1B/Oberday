/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1Receive = ({ className }) => {
  return (
    <svg
      className={`property-1-receive ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M6 19.9999C5.71667 19.9999 5.479 19.9039 5.287 19.7119C5.09567 19.5206 5 19.2832 5 18.9999V10.9999C5 10.7166 5.09567 10.4789 5.287 10.2869C5.479 10.0956 5.71667 9.9999 6 9.9999C6.28333 9.9999 6.521 10.0956 6.713 10.2869C6.90433 10.4789 7 10.7166 7 10.9999V16.5999L17.925 5.6749C18.1083 5.49157 18.3333 5.3999 18.6 5.3999C18.8667 5.3999 19.1 5.4999 19.3 5.6999C19.4833 5.88324 19.575 6.11657 19.575 6.3999C19.575 6.68324 19.4833 6.91657 19.3 7.0999L8.4 17.9999H14C14.2833 17.9999 14.521 18.0959 14.713 18.2879C14.9043 18.4792 15 18.7166 15 18.9999C15 19.2832 14.9043 19.5206 14.713 19.7119C14.521 19.9039 14.2833 19.9999 14 19.9999H6Z"
        fill="white"
      />
    </svg>
  );
};
