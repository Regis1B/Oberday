/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1Plane = ({ className }) => {
  return (
    <svg
      className={`property-1-plane ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M1.94608 9.31504C1.42408 9.14104 1.41908 8.86004 1.95608 8.68104L21.0431 2.31904C21.5721 2.14304 21.8751 2.43904 21.7271 2.95704L16.2731 22.043C16.1231 22.572 15.8181 22.59 15.5941 22.088L12.0001 14L18.0001 6.00004L10.0001 12L1.94608 9.31504Z"
        fill="white"
      />
    </svg>
  );
};
