export { Property1Phone } from "./Property1Phone";
