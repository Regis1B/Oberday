export { Property1Chat } from "./Property1Chat";
