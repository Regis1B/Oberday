export { Property1Qm } from "./Property1Qm";
