export { Property1Delete } from "./Property1Delete";
