export { Property1CheckMark } from "./Property1CheckMark";
