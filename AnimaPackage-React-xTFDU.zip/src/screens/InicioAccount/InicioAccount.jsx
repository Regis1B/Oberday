import React from "react";
import { Property1EyeOff } from "../../icons/Property1EyeOff";
import { Property1Google } from "../../icons/Property1Google";
import "./style.css";

export const InicioAccount = () => {
  return (
    <div className="inicio-account">
      <div className="div">
        <div className="text-wrapper">Inicia sesión</div>
        <p className="p">
          Obtén una cuenta y administra mejor tus finanzas con control total de tus presupuestos y ahorros.
        </p>
        <div className="group">
          <div className="overlap-group">
            <img className="line" alt="Line" src="/img/line-15.svg" />
            <div className="frame">
              <div className="text-wrapper-2">Log into account</div>
            </div>
          </div>
        </div>
        <div className="text-wrapper-3">¿Olvidaste la contraseña?</div>
        <div className="frame-wrapper">
          <div className="frame-2">
            <Property1Google className="icon" />
            <div className="text">Google</div>
          </div>
        </div>
        <p className="no-tienes-una-cuenta">
          <span className="span">¿No tienes una cuenta? </span>
          <span className="text-wrapper-4">Crear una cuenta</span>
        </p>
        <div className="div-wrapper">
          <div className="text-wrapper-5">Ingresar</div>
        </div>
        <div className="frame-3">
          <div className="frame-4">
            <div className="frame-5">
              <div className="text-2">Correo electrónico&nbsp;&nbsp;*</div>
              <div className="text-3">Ingresar correo electrónico</div>
            </div>
          </div>
          <div className="frame-6">
            <div className="frame-7">
              <div className="text-4">Contraseña *</div>
              <div className="text-5">Ingresar contraseña</div>
            </div>
            <Property1EyeOff className="property-1-eye-off" color="#1E1E1E" opacity="0.2" />
          </div>
        </div>
        <div className="status-bar">
          <div className="wrapper">
            <img className="time" alt="Time" src="/img/time.svg" />
            <div className="right-side">
              <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
              <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
              <img className="battery" alt="Battery" src="/img/battery.png" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
