import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { BS } from "./screens/BS";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <BS />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
