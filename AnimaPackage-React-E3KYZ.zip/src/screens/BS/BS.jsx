import React from "react";
import { NavigationBar } from "../../components/NavigationBar";
import "./style.css";

export const BS = () => {
  return (
    <div className="b-s">
      <div className="div-2">
        <div className="text-wrapper-2">Planificación presupuestaria</div>
        <div className="frame-2">
          <div className="frame-3">
            <div className="text-wrapper-3">Ahorros</div>
            <div className="text-wrapper-4">Ver todo</div>
          </div>
          <div className="frame-4">
            <div className="frame-5">
              <div className="frame-6">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Ic round directions" src="/img/ic-round-directions-car-filled.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="ellipse-wrapper">
                        <img className="ellipse" alt="Ellipse" src="/img/ellipse-44-5.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame-7">
                  <div className="text">Nuevo Automóvil</div>
                  <p className="p">
                    <span className="span">$10,000</span>
                    <span className="text-wrapper-5">&nbsp;</span>
                    <span className="text-wrapper-6">hasta $20,000</span>
                  </p>
                </div>
              </div>
              <div className="frame-8">
                <div className="ellipse-2" />
                <div className="ellipse-3" />
                <div className="ellipse-4" />
              </div>
            </div>
            <div className="frame-5">
              <div className="frame-6">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Material symbols" src="/img/material-symbols-e911-emergency.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="img-wrapper">
                        <img className="ellipse" alt="Ellipse" src="/img/ellipse-44-4.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame-7">
                  <div className="text-2">Fondo de emergencia</div>
                  <p className="text-3">
                    <span className="span">$10,698</span>
                    <span className="text-wrapper-5">&nbsp;</span>
                    <span className="text-wrapper-6">hasta $13,000</span>
                  </p>
                </div>
              </div>
              <div className="frame-8">
                <div className="ellipse-2" />
                <div className="ellipse-3" />
                <div className="ellipse-4" />
              </div>
            </div>
          </div>
        </div>
        <div className="frame-9">
          <div className="frame-10">
            <div className="text-wrapper-7">Presupuesto mensual</div>
            <div className="text-wrapper-8">Ver todo</div>
          </div>
          <div className="frame-11">
            <div className="frame-12">
              <div className="frame-13">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Ph book fill" src="/img/ph-book-fill.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <img className="ellipse-5" alt="Ellipse" src="/img/ellipse-44-3.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame-7">
                  <div className="text-4">Educación</div>
                  <div className="text-5">22 transacciones</div>
                </div>
              </div>
              <div className="frame-8">
                <div className="ellipse-2" />
                <div className="ellipse-3" />
                <div className="ellipse-4" />
              </div>
            </div>
            <div className="frame-12">
              <div className="frame-13">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Ic baseline local" src="/img/ic-baseline-local-movies.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-3">
                        <img className="ellipse-6" alt="Ellipse" src="/img/ellipse-44-2.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame-7">
                  <div className="text-4">Entretenimiento</div>
                  <div className="text-5">7 transacciones</div>
                </div>
              </div>
              <div className="frame-8">
                <div className="ellipse-2" />
                <div className="ellipse-3" />
                <div className="ellipse-4" />
              </div>
            </div>
          </div>
        </div>
        <div className="overlap-2">
          <div className="status-bar">
            <div className="wrapper">
              <img className="time" alt="Time" src="/img/time.svg" />
              <div className="right-side">
                <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
                <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
                <img className="battery" alt="Battery" src="/img/battery.png" />
              </div>
            </div>
          </div>
          <div className="frame-14">
            <img className="ic-baseline-arrow" alt="Ic baseline arrow" src="/img/ic-baseline-arrow-back.svg" />
            <img className="vector" alt="Vector" src="/img/vector-2.svg" />
          </div>
          <img className="element" alt="Element" src="/img/10-1.png" />
        </div>
        <div className="frame-15">
          <div className="frame-10">
            <div className="text-wrapper-7">Pagos programados</div>
            <div className="text-wrapper-8">Ver todo</div>
          </div>
          <div className="frame-11">
            <div className="frame-12">
              <div className="frame-16">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Dashicons admin" src="/img/dashicons-admin-tools.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-4">
                        <img className="ellipse-7" alt="Ellipse" src="/img/ellipse-44-1.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame-7">
                  <div className="text-4">Utilidades</div>
                  <p className="text-6">
                    <span className="text-wrapper-9">Renta, electricidad, agua, comida </span>
                    <span className="text-wrapper-10">ver más</span>
                  </p>
                </div>
              </div>
            </div>
            <div className="frame-12">
              <div className="frame-13">
                <div className="group">
                  <div className="overlap">
                    <img className="img-2" alt="Eos icons product" src="/img/eos-icons-product-subscriptions.svg" />
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-5">
                        <img className="ellipse-7" alt="Ellipse" src="/img/ellipse-44.svg" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame-7">
                  <div className="text-4">Entretenimiento</div>
                  <p className="text-7">
                    <span className="text-wrapper-9">Netflix, spotify, apple music&nbsp;&nbsp;</span>
                    <span className="text-wrapper-10">ver más</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <NavigationBar
          className="navigation-bar-instance"
          divClassName="frame-17"
          divClassNameOverride="frame-18"
          hasFrame={false}
          majesticons="/img/majesticons-calculator-1.svg"
          overlapGroupClassName="design-component-instance-node"
          riHomeFill="/img/ri-home-6-fill-1.svg"
          text="Trayecto"
          text1="Formación"
          text2="Movimientos"
          text3="Perfil"
          vector="/img/vector-1.svg"
        />
      </div>
    </div>
  );
};
