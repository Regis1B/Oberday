import { NavigationBar } from ".";

export default {
  title: "Components/NavigationBar",
  component: NavigationBar,
};

export const Default = {
  args: {
    className: {},
    overlapGroupClassName: {},
    riHomeFill: "/img/ri-home-6-fill.svg",
    divClassName: {},
    text: "Home",
    hasFrame: true,
    majesticons: "/img/majesticons-calculator.svg",
    divClassNameOverride: {},
    text1: "Budget",
    vector: "/img/vector.svg",
    text2: "Stats",
    text3: "Profile",
  },
};
